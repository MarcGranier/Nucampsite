import { Text, View } from 'react-native'

const HomeScreen = () => {
    return(
        <View>
            <Text>Home Screen</Text>
        </View>
    )
   
}

export default HomeScreen